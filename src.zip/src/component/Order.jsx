import React from 'react';

const InspirationCategories = [
  {
    id: 1,
    title: 'Biryani',
    imageUrl: 'https://www.cubesnjuliennes.com/wp-content/uploads/2020/07/Chicken-Biryani-Recipe.jpg',
  },
  {
    id: 2,
    title: 'Chicken',
    imageUrl: 'https://media.istockphoto.com/id/1265212634/photo/fried-chicken-kebab-or-kabab.webp?a=1&b=1&s=612x612&w=0&k=20&c=zrL9vS2OQy-4nuE4kpCfJYPfxnGxtO6sY8GaoPi3bBE=',
  },
  {
    id: 3,
    title: 'Veg Meal',
    imageUrl: 'https://static.wixstatic.com/media/a94a23_aa674298181e422db3f4da9c8bfac4cc~mv2.jpg/v1/fill/w_568,h_320,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/a94a23_aa674298181e422db3f4da9c8bfac4cc~mv2.jpg',
  },
  {
    id: 4,
    title: 'Pizza',
    imageUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBoYFxgYGB4YHRoeGxoeGxoaHxgaHyggGholHxsbITIiJSorLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGi4lHiUvLTItLTArKy4vLy4vMistLS0tKy0tLS8tLy0tMC0rLS4vLTAvLS0tLS0uKy0vKystLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAAIEBQYBBwj/xAA/EAABAgMGAwcDAwMCBAcAAAABAhEAAyEEBRIxQVFhcfAGEyIygZGhscHRQuHxFCNSB2IzcoKSFSRDU4Oisv/EABoBAAIDAQEAAAAAAAAAAAAAAAABAwQFAgb/xAAyEQACAQMCAwYFBAIDAAAAAAAAAQIDESEEMRJBURMiYXGR8AWxwdHhFDKBoSPxQkNS/9oADAMBAAIRAxEAPwDJ2cElKQKlQD/WJlpsypMxKwSCAcJdiOR05w27C01BU+HEzsWrQBzlpE/tFM83+1iPV/xGdra04VIpPH5OFJqV0MvLtJMWlAWmWChOEKKCokAM5JUQSWzivtV6TUoCJmFYFUgpyolTaEUIy3iJeAUkpYspKR/+iWbUVHzApNo74nvMySp9izD0/HCOJVJyle+C/SjF2XMtZV5qWlIbu0EEgIq7UNcz6nWItqm0JUGKiABnhSkEAcy7xDky5yAXDs2EhsiSTx1i/ue5lLWJk3wSxVjmojYfeKdapCCbvguwTvcn227yZUpx4sCR9ozFrQxLAOPEH3TUelI3NrnOSRoKDQMGAjHzkupzoCTyFT8RS0dSXM7qYyim/wDHKggkMXANWrTnFbfE2ZOmY1gpSVOVM2fAZCHXLKxLG7gD1pGrvqTLVNKJCQAhHiLuCUjxEHWNvFKXdRo0lPX6f/LK177Lp183yRCuG7Zk0FJQhkJxYl+IpQK4lK/U+gbJt4bbLaqViPgUp6KCQCwo7hndmHIwywXqUJmy8QdYALj9I0Fa6RBttsQlCwSS4QEsBTAMIzr8w0nOWSsoxoQinHreXNNbr1x0sudw9ltc6ePAkJSSPFhDPpoSYhW29p6ZiwPIT4WpTL9O+3GNupctFhllCvGSQQGaiWCqahwPWMpeVnCCFKepSoFQZ60PIwqdRdMDqaWU6nRreWLNrfFs42uOsd3zipCpisILjDzSRX3iiVZu7OdHOHiN+Eek3veEmZZ5CZYSFpQAskANUfPGMHfiQlw6XSWBSaHdt94701ZuViD4loZJOpa1l/Ly17t1WBSJkTkK1insCni4kB40jz7RIoa0+dh+IUwPvR/45RxKAkEJFASN+LGudYc1AemygOTtmABD/wA6AfPWcEXMYO1CaPWrVb16zhgRSmY19OveATxkIAOzZtGq/Hp4iKEGaBwAMgstRENMdQIAGhBz0hk3aDg8IbNEICPhpDwG/MObaHyS9Ot2gAegb7GsFdsub8ctOqwRMtty9C77wOaAmj16pAAC2PjOz5dcIGuvI5wZanNR16w0J58YAIihWpEKDqHB/VoUAHqvaVcuVY5gI8S0mXLSc1LUPC3LzOMgkmMdaLarC6gDNIQHOVH8TZ65b7MYFJWpSwSStamSlS1FRAOjq5R6Fdt0S5M3uUSxMmYQVzVmrnbYRn1qcMKXL3Y1tHoITp9tVbtmyVru27u9ly6s8wvZQKQpCnw+Z8yH694jWeclwEg1Zyd4tO1EsibMSoAFKiKRmLNOO0DvPvJZLOt0cdHZReJK66l7IvBSSopURlrFxZbYpVVKbermKGWW8wDEZg/Lh6xZWEbAbuS/WcZdeCy7ENKeNy9XahgYZanreM52itKZcs4c1gpH/L+o8v0+p2ifKUZhwy0mbMceFJ8I2xLySPV6ROs3YjvFd5a5mNRphRRIbypfMjkRnrEVCnGm+KW3zOpcVTETz+70U4mLA2S0nyWeYTo4IHuY9euy5LPLAwSkoIoVc+O8TJ1nSP1/qzBAA/eL0tVF54SbTzrUE4RnZeS/J4fL7IWxSsS5eHmpI+9ImjsPaTUoBAzUVOB6x6xb5YxEYQXGRU5PHjEC2W6XLlqSpSpYILDAfEcsxnn8wl8RneyS9H9zj9DGebt38fweb/0lplywDJmFDOk4SaEUqNGiht8yZMOFTpGxzpzj23s3Plqscl2UoSkOKMGSKB8iPiFed2JnBQWAQzArSKs2wNeOdY7jq4Rm2458GSVHqJ0uxdR8PivrueNWNMwhicoj2qyLJc1zj0W29jZeEKRMKVHRioA60NW5Es2UUlpuG0S3eWVAGpTVuYzFOEXaNfTyfdaTM/Ufq+HhqNuKKC67OxTiQWcPUAtzLsfSLKRKIculnASkFzUGvKlcsxDCqX4SqgSQSX9G416LRJsctpneKCSnCRgIpUHVwXBqH2i2Z4xKQPDkVOw3PP0g0yYWIbM1dutIOEpKScIUoAMrLDUOSMy5em5eBmVuR00M5ZGM18zT3h8+W/7Mf3z+sFmWQFOr0NRoRtzf67Q5KSzKOQoXHwTnUwxFVNSxjiRBe5qeuhASWgGEDa5QVbAdcYBKGUJUADXeFXXKHolg6t19IeoNrAAOZkS0DQ2kG6yhgkmhGsICZKqlzo3RHWUAnDxGDWbLgC5rvA5wYwCAgfvCP7mCSxV4csACrHOkAAlShuP+5vvCh+Hr+YUAywqMjUFx0I1Fo7UWhUhDJYgMVhnLfIi27H9ge9CZ1pH9tSXSgGpfIqIyDVYRI7Uf6eS5iD/Sf2lDUqUUncMX9xFatHieDb+Ha9UI8FWPFFO66rr6nlt83kgocvjAVV3K1E0poB9jvFh/p/2AtVsl9+nAiU5CVLJBUcjhABp7RQ2y41y5qpU7zp4uK6g7R65L7f2ayWGTKkIKpiUpQJQBDEAYiTkzvWCMeBYIdfrv1dS9rJbIxF+9mZtkWETk4X8qhVKm2Uzvwzi5uHsEqYQbSopQKlH6iDxJp9a6Rq02qdaJIXbJctJNZcoeIgM2NT5GtB87QrqvRJnmVMWAGLLJzIPlJ3I11ZuebqtdLj7OmrvmdafRXg6kti/s12yZPgQlIA/SNNoDeNqSlIJJz8NAB/NYmzbIp0YEqwuFLWlhQaOasdhBplhlTE4yMRYhIrrQU/O8UnxtNbe+vP7k6lFNN5Xv0+xk71v4y0MqhUaDMtuRpFXd/aNFO8lFZJ1Yp4eF/WIXaBJFpmJNUpZAarUp8vAJUtqtp/ERSirLjyzcpaanwbbmnuizpn4ihdAoYaAKT+9PZof2wsgNimv4pqZaxiw5BNTwALEPyhtxySibICE+KalWMOzMUsPYg/8AUfTR3mnFKmSgMWMBH2IL6NrFuC4Vt739TNrTarb4v4eXvqeN3MqYqyhXeqGEuC+VCK6tWNlcN+rAKbSk+EHCrIkh2LUJoBUbxQ3ZYF2ezzJcwDvBMUnC9HBw5jesemXZdoVIaclJo5SQ9OvpHa78pJddyXVThGMbrH9lOq1yirEFIOJ28dKln3BfT4iR4AKEORmFeHk4rvEW0XGlC0zSSnA5WAp04WqWzf4yjKm0kJUJTplkkgZkj/mP0EVeBrMXnxQU6Sq7PALtDcoXMUfLq/6S2RUlqcxxMZqYhUtWBaSlqgE82IIzzMam7rwtKqkFSC6ClQDsR/kKH9vWHWyyy5sru8Jcl0qJHhD5V0zDRe0+snStGrlFXV/DFPvU8P5/Yov6wlKQCwSpSgABUkDM5scILZZw2yrfEFBnUWDs/EgOBn8cIpVWoBSkYgtiU4h+rR+OojWIuKcJWNfm1Sf0g6EZv+OEatSvTppOT3MOnp6lRuMVsRZi3KlEklbOS7sAw3ow2DtEZSVYmHJjpXKukCtFtYkEDFqC713er5/Ecl2nNxm/Lr8RMrWwQNNPJHmggt168YZg6+YlzUPXXUddVgJlluW3WcMAOUKH939IQl9bQAM7w5QVId9xCTKfhBpUvP5gEAJDdfSOAh6fMHVK0PqwgZlMeTwhiSmtIcoPU/zCHVY5iADfIhiOpUDQ0/aDzZYbxegfSIyTiiSZeJWwG/HjCAgqSXy69oUSFWY9NHYBn0FbryEjDLWUpKi6Ug0CQxOIn1pFebzlKKJSpoSS5BocVSQKmlPpHnfaSVabR/5iZiSk+RBAoNCwLn1jD22bPPgUugqGDfUkjlFKLcnZG1X0FSjT7Rq65tWdmbj/AFMueXKWi0pWoqJCFuQxB8pDAMx2zcwXsJcvfLExYHdpUAn/AHKzz2Gv8xkrNYJ9tXKs6pqyMTh/00qSGyACmH5j2SXZ0yJCUS04UAYEjMkbk7nM84i1eo7Cnw+0veCpp6SqT4vdyB2nvDAhRl6PXXY8x+Y8+u9BmE4mwrOTPwYgxvL0kJ/p1oYqWwYCpckEBnypFDY7tVLIC0lJFa1oeO0YEJ2TlLeR6fSOCg0v9mn7N20Sf7appKSkEd4SQhQJcBRzBSxZ9Ilye1dmdivV6JVk9NNtnivsVyd4nFN/4akkVqSSCl222jCWnFYpxs8wFUv/ANNQpR2bm9PaLalV4fexXjptPVqSV3fw/wBG67R3Im0KE2SxJYqALO36n3iiXYFOxGFKQ5KtBpz2gF13mqSvECRLUwIP7HjGsVL75GIrdKTiUARVADsofaKzTm7pfYlc56e0JO65PmD7PWpCzjYglLh9AQPrToRKTNUpSwkgKBZKcQd6+I7PoNoydovjxHAChL0CNHrVWv7xy7b07mYFEHAsklRGZJFSQHzp6xZVRSTi+ZFU0cszXoaebYZKJEqZaEAqUxoHxkh8R/yzfnFraLQtEtRlpKlKAAAG/D1jt0Wkz7FIPdgnChwWozOeYiWiYlVU4VqSVYasxFFDnFvsrbPdL8+ZlzqNu0ls35eHkV19WcqkTkuDNMqpGpAr8/WPM5wHdpYPVi2hGXvHp0q3EzFS8CjhqVkUry14Rl+10izSpZmklBUfKG8R4JpUxVqXkuKK2w/fMv6Gv2T4J88qxUS7V3UnEk4EgYlklhSj1yf8RibbbptunqsthScMxRJIoGJdRP8Agjc65a16Z67yny7KlWCSKrIrQa5+I7Cgc+semmzyLrkolWeWkTFAArUAFKapUs0xGuXGJ4LsY3lmW6XJfk41FWWon2dLZ8+v4M0ewiLFZ+9ChMnJIOJYYEB3SgGiTRwTXPSkbIo72z94kggpSUkcQyh7vTiYzt73nMmKwFamAdQdnPAZfEE7N3l3CzLU5QVnkH81NjnTWK3HKSUptt/f7Fj9JKFJKKWMmZ7aXOrEiaKkhiwzw6Hi3vFFZJ7jhycng/Wcew37Zpc1LpIZ0h9v20ePIb9sX9PPUKsS6Wrzy69o1tBX4lwN+Rha6j/2JeZIl66U110/MNUjV/46+sNlzXahO767lq9CJNpS9QOf2pvGkZpGXhejv03XGCh/MBp16wAqxEsGfOCInYdcv3+YACggBmrSExGm3XrAhN0/EcmrIAH3gEHJfhv0TCWHJ26pWI8snLSnE/FYOjU55vAMBgaGEUghhrvCAbJDKHr00WK10JarvSjftllFchOvXpE9CnFA3A6/msAEfBweFE8WUnUjg7faFAB6Pf8Ae8iSmYolK1rDBLO1GYbD8x5Je6SlJUoFJbGORyMdtk8pqt+ZijtluXaFpkoclakoBOpJYDlFCKbd0e5ruhotPKDldyWz3eLLHI9g/wBKrrxSv6pYPiJTL5ZFR9j7Roe1Np7qQ6RmSHJojYnmw94PLlJstmlSUMcICUgcA34jA35aVz1qQ5KEktxILE8qRlamqqtRprz8FyMvQ6VytnCNT2MQh1/3AqZML4XDsEtXbltGktViUDLarsCl6Nm53p0Iw1nseCUkgsoZYS+GtMjnnG2s98A2cT1HCzJL5OGy4sY47klaS2X9HeqpTjPjg73dv55D7RahLPduDixKWSzIYOMsvWMX2queWuTiJr3jua0UwAcZ1ILiLOXfcsrmkoWtCzwBbJiNfeCS1SpklZKKIcgOaMxSVB9/kRy6nFJW2R1SpzoO9nyv7/oyVn7PrdMqYvAlJPirQgAhOVFGvo8a6wLspxSQcDJahOEmuZq2b10JyiHfFqSmzCc/+OMZkEKzrTJ3eM9dd9WZS1ISoyQZjIVgJxFSdWYJr7MImSstrrcsS/zK8m1bGOpAsUpZmLltXGQHphrkYvLfbRKsoJCQpOIpJG4GfqWDbRopvZkHCoLAmK8ymCgafXjFB2ouyQiWoTppWUgITLSDmcstTxjiNKaldq3tHctZSq2Sy+ln5ehN/wBMJyu4QmZNUf7bhByFW+8TQkImFRWAfEAEOBWpiqsalps8qahDowAoTVykpDFwOJNamkQr1vpMtPeE0bxIWwDEVqBStY6lJSaTWUyvKk3Jyi8NZ25e/wAl3et9IkS1KVPCSVAGmKrP5RXKukeSXvbJ142pSJSiuWlwFmgCXqrg+2ZyggtE68Jq0SU4JZfGtsTJOeYoTsKngHjY2W5JKJahKVgQBVIQxWRm5NWpWLMqvYrvfu6dPyQUqMazai7QW7tv4Lw8SPcd3SrOgplsoGilHMq1Lgs1CGi37UoWtUpZDgunLJVKcCRE647slp7ohjjU+AlwNQonfXaLq9ruC1GW4YkEtoQfMDuIqpOcHLe7JnWjSrKyslt5GBvFioOWoA2tasIPYrGUKUolnGIA1ADgv/2gxeWjsp4iAsOk0BDg8Sxy/EK8LAiUCkpMxS04SlJYgKoTvk8OMZWvLBZnq6bXDB3uCuC0CdZi9UhRJGoSVOB/2mMp2ws6FJmCWXUhlB+VQOtRGv7LWYCUtAfE5BU1CxJwvq2/OKrtDdqUiaUpZWJLE6pIILxxpp8NS/RlPURU1KL5nmNmmqNX3i4syjSuedGp01YogvCtSRRiR7Fon2YvlHp07nmGi0mnZmH3+dIr5k0kwSavRjAjLIOUMQeWXocoKpVOOkR5QL0gxJfLl94BHEKbOCd7RtYFMW+f7w0UgANrxjuGByxV4OIABILRJsiy4D+2dNveATBnDZAdQ064wgLAIQaqJfkY5AlSiS4Sn3H3DwoBFh2inS5i1FCfDUDbhFJ/p/d4VectOiHmcgB9Q9OQgtvti5UtSVMEqIJFHcZcRHf9NFhVrmzVKCWlsHLeYj3yjLm3ClOS6Ht/i8qM3Tpp5Txzdrc/5PVL8thUTgDEIISeJevsPiKeVd7LWVFkZg7vUsOtYMbZKVNIVMR3aUuo4gAA1ASctucT5vaGwLMqSFpUQwAAUpLNqpNAffkIw6VOc05SWWRxqdklGKdvAm2RUooCUIdLuSdS1SSczQRSX3MIUJZ8gAWEkkZu3wAY10q3WdQQEhROeFKDltRIoKe0ZztFdWL+6CoLSTiBSoPrQEVz6aJqy7pFpqq7XvJrz6lZItRmeEpdQBJagADMkZsM8vWJdglE4A2ETcUspzzcl/aIl23imUFgypqjl4EEuRo9DmBAF2q0zZiBLsy0oSSU4vC5Zt8w5z1jqFmry3LdTdxWF1JPaa78MnuVEpSpb0Y0D4R6O2TVEZO3qTLQwZIYkGjk8s3jWXjc1rCFTJykBAJKU5tzI5ksN4qLddbeKZgZLKOEk0UKGgyIjppqVnt0O9PUjwbpsurpTaJUlBXMIdnRoHFQ70PHnEK8LHOtFUTO7YELwnF4iCPMRmxy+kGtPaBMySE0BZlJBxKB0y30gd12vz98FJQDiwsRiUd+AAHvEFOdS+f9fg83P4hWpTmpLvfL7hrXaJkqUhMtTIlgJSXfypAbjv8AWPP7RZJ9snlKxhkILGuEKOFwKVOmWUa3tBe4KSqoQKCnwAI8/mXpalLJlOkHIJzA55g8ot6SnO7kreDY9LXqVH/kUnHmkt/Dy6npPZ23y7GVS0SkgBqPUkB3atPXTXSRd00Wla5gSp0hk0d3dyWPAj1jBXd2ct82uFOIjEynxEHVwM34xb3TZLyszqXZJik7JUkU5YiXyIpoxjupQcsqSbXj6mt+ppRTtFxb6r6I1M1a+6XLmDDiB8qWUDQBKQAOGX8yLJZJ6JaVSZRMxBNJhdklnUMqMT6mMRZL7vCVNVOVY5pAcF0rLVcHKrNnzgtk7f2wKWoyVqCtvCwd2HhqPeCGkmsvP8r7leeqg8R+T+Vj0q95h7tJXNTLPhxqGbahOvKIqbxs5UkY0rDMVksoAaeKpfhHlV/dsTaJwmLlqDJCcBINQ9XLb/EQ13+CCMDJ0DCnqDHUNJVjK7V/fmKNTSyhZ1LPy/B61br5CLRZxL8k3E4ZtmJGhdh6mJHaNHeBQDVZy+TF362MeTyO0fkJJPdqJSVAqIBDEO3TRq7X21s8xBSlbKIzKVpq2WTNBVoVOLijF7HHHRVkpo89viQ1pmDTE+2YB+8TLKyRn8ddPEW+7QFz1LSXBavoN4fZVeHKNql+xX6GHW/e7dSZidzly/Jji5hpuIYk9fzHTnEhEPlzW5wkrSOekMXlDQNYAHzJznjHZZ3hoRWCol75QCJCUhoIWERwWNI7MnPpWADqjBJMvU+n79fWI5UNKHrhEmWsFLD41z93rAAY1qB8gfDwoFh4t6+0KACts/Z9U+YlEtJUtRYD8nQbnSN5/pvcYlrnS5iUhSFpCwqool2f5HOPUrSuTIld1JQhJPhQhIFOfHcxirrWhFtnyklymVLxcSkqc/8A2+kUNXJSpNeXzL+mTVRPz+RU3yZaFIwy0pIWXYDUMPkH1i8lSpYZYZzU16yLRF7WWCWlDuXJHFgzg0roX5w27rQJiU5YQkMGJL5FTa5NGHSjKKs90elUozppxLCXbioJCaLKgzZ1LGvKvtF3eKe7SFlSvMPUgvRq8xlEfs3YBiKwCBupJz1NdIru0N4Ll2lOIES/EQN2DUAyf87x24Ph45eX5KjtUrcEOWX9jl4doZmNJlyVd2dCwKj/AJB3IYiJNqnGYguyC3lJHmFQfDU6u3CM/PmTFrCu8IxDw1oMqM2dMvxEiwTZqJstFFqKj4icgxc1pHUZvLeffQsT08VFcNk173ItxdpZ02cJUwpwlKwsLDOxGGmTkOPQxe3vaEy0AS0pCqAFIzAyHIVaMzaFiVa5hwVmqYqLFgkUALsHJNAG8IiXaL7QlTs6gGGw9N44raht8Mea8TH+IS7NqEOmSOvFJactqnEzBzhpVWjAk+kV96z+8LJ8JKnpRqAUOjAQC87cVhlOEh6a1JJ+sR5dlVMBCSQAhRdtm/MKFKTSkyrToTrOLb9ehY3BdKZ6sM0qVMSXCnbGlyzV9+UXA7Nyx4EkpU5IG7UcDQ/gxkbLeE+SyqLwEKAYigpQjQjf4j0a4+1NmtKRgdC2JKFVPEA/qbhE9SPHHBtyjWoPF/4HXDdapQX3hPjThqXYaVixn2lJMsFQ8asOz9Vir7QXkEBCF4mWTiKPMw1HKKG13StU3vDiVKCcSVA6NRPN8+TxD2zhhLFjlUu1705WbL6+zMTNWpAQtJAxALGJJAZmGSq+sVwu6zEJVhJKjhU7KL6NSho0FumyT1oJErCZqhiLkeGrn/nYxHTdBRNV3SiFBTnESX8LMCMql/SJKTbfaWx75nTtFcClldPqdt1wyU2fvFSwVlTYQdy7eHYERGXcMv8ApgFy5RUEhRxS0mrcc+cT7fInFUkBCSZaipZcigIcpHByK1O0SbdOSUBBNSK1yAduWYjmrJ9pFRxj+8CveGc5POe0FglyZZwy5YOpSkMzA+Fsi7vGXE1J0pGm7YWsdwAkM5qM6uMXu0Y2SqtRG1or9nlmNr2u0wuROmSQS7U4wYBhwgcuYSGz/EGWHHVYulESTpv/ADBES3ygYfbKHJD6tAIdx2jiYeDRoHAA+Wr8weWTEZIiTIV9dm+YBB+5pwzygM1I9euvaJJmsc+tIjWk7muQ63gER1mgo0NRNIp6GOT0tX3gKC5EB0FMzp2+BHIRA3EKADezO2wkSgru1KnkEKV5jTMj/EGM/wBjLfOVePezHT3oKCDUsovi9w0PMoFLlw4qC1C2o3em8ckykpXjSGXQ4mfKo+YhlRTi11Jo1mmmeh3gEqQrvHKAlQFMi1D8D5iFZrxUoosstWAzMS3P6SlvCKZEYjEqyXgZ0hOEpaYWyyIZwTo0R5ltSmZMmTACJQKkgAAl0hJL5CvxWPPPuS71+jPRU3xKy819MF8meuWgoUQtPhILMaZu1M9IFeN2f1CEzMPkIOfmD5P1nGUsfa6cUlKLKkhRJxlx8H6xoLkv5c4CVNZCmLEanPICOJqX/Pbla3pn3yJHRqU+/G11vnl1sgsuxGZ4sAp/0impJYcRhiJPm92ZkwBICGCXq7+bIUiyvztBZ7OO6JLswo+Qc1yy9N4obqmptisQSRZkggqdiuooEnMUqfTeLEeHg7zz9ediK9R5taP0/JEV3c5S5y8UuzkjGokuso0QB4sszkK6u1ZOeatS7LKX3VWUsgZbHI1eLztehKrShBS8tASAgUBSzhO2Zry4RHn3iUykoCWDlthqpgNK/MRNwzfLRZ/TxqqMpRvfryX3I1gsCCJk1TlSc0s5GLXbf4iB2avGYqemUEFYCJuPQnyhIGEbs+esXl2pXMJQweakl3aiSXOznL0gnZS70S7ZPVLUO8TKAQknR3USdlKAH/TxiSheTvyI60YUk0ln6e7lJ2nuyZZyVIbBiYVYpoxFcxQ8YqOziv6ZQnrYpScRSNmYniW+kb+8LPMXilzEJEwqStQDEAcsq1rxMckWCzzQUUOBYSsGv6cg4ap6eIlKabhbn5E7rp01xZLeSqz2gJmql+HDUqDHgnj+8V17dqZNlBTgKljJCckuAU+4O31inwmzIWxUpIYgKo1afYej86K8cSp6lqDYyFAH/dk2h2ptE05K6dvkV9Ppo1JNSeFsrl5dfb+YMRmymS5YgF0v5Rnwh12IK5vfFSylSit5Z81CCM/VuAasVjplpUGClKUA3DUvpEiyESLSJYUEgJKiahiXDnenzHVOTla5LXowppuCtf8As0kq3oKi57shLYlEqUwrWjB9H4RT3stlImyziFQK1IIq+r5RbzBLUFKUEgfpVifGAM2zxNtlGWvWaC/dqASaA6Dcu9c9Norw4p1bsrScVHBie1toSViWMh4jzy/MUslIjtvmBc1ahk7DkkYQfYP6xyTHo6UOGKR5+tPjm2T5Ran0g5O30gUhLD7wdIaJSAJlzjiyNBwhCOzFDbRngAaBDgkEcY5KQ8O7uvwf5gAaE5ivXX1gktOvW3vXKG6nUVr/ADoYLLABB1648PmAQlAkM1dtm+kDWSHB5/HXtBJ1Kgivzq8Rcbff6+mkAD0APXLofaBzJeo3NPpHMUdx/EAzhQY5D1TXO3XKFABoVzQkFSlBIDEn4yzJLcIhW21JSslCFpQohIJOIkjNahkhw3hFA28Dn2pfdt4MIVjJUACWDEYgHJbJLxxaDMSygBUlgxoMjUZ8445nfI0fZW1JxGSssFeJJzqBUeoA9oJ2nkrQk+J0YSA2o8zdbxk37tphmkqwJWof+2xOZZiugNHzjfXfaE2qzhCs1itA4JAYjd2cfzGbrKVnxrn8zW+H1+Huvl8iruueZklycKAyUjJ2zcu43pFnawEAKBdWYIGQzBzPN4ALplylIlzF4FAuUqHhfdwaA0zgdlKLXNmALKUoBQZhyzBIFWD0rGdbjb8DdlWjw3iWlulf1eBAZcli8zCB4s2DiihrXmI0FjXJEkSpOEIlgBnALDhqCSTFVel/ypQSa4QyUJBZ8IILj9A48szFRZe1MpUzEZPdJJLqT4tGYhhRwDEknJMpKjKccJ2XzLy03UJswTMQCgBxcB/mrVpFDbbEcdCWJowyZ3rk+ftGvui1S5zrwkS0ilWKsmo9WrEG9b4s6SEJIVhL4QTo7JcA67RUcJtOWLXZJSrzi+BJtpeg+y3WEy8SSy2YAZBI0J3epjHWCxFK7RNWtRLhQKRmlJUGxDIu3BjHoX9eJiHSpOEtlpTykbwCxoQJBWEgkjCnZkrVTmSSX4iLqj3OG92ypCvOM3JmVRMmzLT3sta1ImABRIyAIIp8Pzh96XuLPNTLMzCCQpeFIUWf9WTU5mLS95ikShLSQh2UtTVfMhOVKM+dY83VNXMUCRV1EnPzV9gAB6RyrWvfYu6eHayysHok1KJstpU5KgcphIJU1SSBRxSkZu3XenwJDkKLpWKhCjQpz8nDR+JaJY7HMT45a8B234Nr9oHa7wmYQtfgXjZZxqZkh3SCG1yrnzjmPFJto6lSdKSs/wCbfMImbNQcXcheFghlFi5LMKnOsSbts0xzMtNFTVgF0kBWYCeAFDzEZuwTZylYZalLWuYMPiwjMGoH24xsVy8EgIJdSVkjM5jxHMhgcvTnHdSLilFPcUqyd8ZQe97wUkd3LKVJQMJBAIDVBy8J5Zxhe014sMCV1UGIGQGTuN6/MW9929MpJNH21Onv1pGAnTSpRUcyf2i9pKC3MTV13bhQk8BB5UqOS5NHaJMoRpGYSpaQwh40bWOpow5QUIbr2hnIN3pHZsnTSH91r7wZaXzDdfWAQCQRxNIUyaX+I6Ut5eujEWYS+UABVreu1I4lRaApJMTZNB9G6y1gACoHNjHJjMNM4kTZ3hFHG1PpEcEGpLNtAAF46I4oRwGAYmfaFHCecKADUWQFCKpGKhBIBLFNDXIsedYLJZYwrlf/ACJooPuMiIpEz8KiEHCo+IhqbB9zGiujtNIl1nJWgjPCnGk8tfSKE6LcuNPfmjucJRdmrMqbbKwLwGr1HEHVo72ftypExMwpBr4kpLOBkQdxQg/mO9pu0FntE5BkBSQgEKUpOEEKIrUv4W214VgWe3pUlafGQU5JOEKUC6HJzSCHIEWIXlTtPfmEW4u6NxIlotSlzJiiJS6pfNRGZOqQDTfOJqZHclKQQqWEth0roAKUjz6y26ZKqny5kPtr1nGwu+9ZE+UMH/FHmGRG1NBTMOC0ZOo0UoJ226m7p9dGdk/T7Ae1UtH9pQSAquIZOApgfYimlYEq8GlEJSkUIzFA3CrufiFbrGbQkkYnDtQunRzXKkRLusHidctXhqQlnpw/EQJtLvs1qUqbjjkSJNqXKJlJSxUML6pDVDn04wJM4IJQQcRYPrmMmd4nqSrAubNHduPChdGSHB8RNVKO3CKyx2hAUFqIDv8Aq3dq+3vC4ESwmndpGgupZlomzMQCEVIZw9Nd2BNI1l0Tkf0stalIw4ElzQHdq5cTHm/aC8paLIpEpYUpaSFHh+qmVct4vbDbUdzZ5amGBCBoCU4A9X4+0Tw4owujO1UYylkmXkkqInLdUqXQV8SiXzDMAPknhXM3jYE4u9s6kqQt1BJOFQALFNdRlxjUokpMuaELxJUkpCScQeniGpIaM9ZLiUhSkzAMLMkp0epPmrk2W8RpQStz9R0qs4vu499CPdt9JlDCEHGosfCSQ+bH4YfeLCT2UmTQTPJQhSgSFECiR4Rph0dq0h1ns0qzqTMSMayWC5hDDKoGgH2h95doVqO4GqX1/wBw0zLfiHb/AM3QVK0n08QltuKRISZUgB2BO7u4VioQRo2UVVvveaJX93CnugAt9QfKUgCppXiOUCt95JSorUHUQ7MwHFjlvrGJv2+1TyU5pxYnIqSzPXKkT0aEpyuyhWrxpx8SFeFuM1T5AOw+/MwKSiGIS5ibIlRsRSSsjHlJt3YWWKNvBUJhJTSH4DppHRwElpr1zgp/mGpzblx6MFTlmOs6QCGYiMm64x1Myg4V4Zwu69+q0HVY6ZQgA73wfUfGXpAJgJr6wVUvN9fVobg3gAFLRw635RLSQQ2uZ9OORgMxTM3pT3+8DSes4ACLUBrvk2/CAqQ+UNmEvWH4nFKdfzAAMiGhNYMUuDwNX5/MCcb8hABwpI/mFHcfTwoALGTZDMnplpUC+oOcWvaK6pdnZGIKWzltIxtgtykrxFgoJJo7tSmbPrlFhab2UHUVVIao0POMmUKkWop4PaUa+l1PFWkl43Sz0zyQGeoEhISDUYn+3WkWclaQC7sASAkAl2oGJGZjMSLSVTH3pGjkqRhYrAITioFKUonJDAMnJ8RNHGcacb2V9zyVfg7SXB+2+PIbLkEr8LqKmASK8mGccnWFaQlYdLvhUKElNCx4ZQ5Km15RNtNgQhCCpeGYo+JGHyo/Sp9d2/EdEQ2y39aZctSWJS4BWBrWh5h4tLHfEqcUJKgk4hiILMG/xIBz2ioCpKgZeIoxKwpLnxAGmJAfgaPU8K01rlyyrCkLyBdQAr6RWnpoT2LVLWVIHpyrZhYiYsgUOr7tRwOdaxEt3Z+XNCVAtMIr+l3ozmmWvrGCsdsnyi6VcGUMQbLXhFijtatgFy8tjRhTIhx7xTehcMwXpgvw+Ip7uxZXp2ewmWgKP9yYlBcgggkbZFuMbBcuXJT3WEEgHCEgVfjT5jAzu0kpRQpynAp8ATuDV+D8YZM7VoSsrlhdWDHhxOXptHH6eq2roklq6dr3Nau04ElI/wCJp4WbjsTEC13wqUlKQllKOF8WJZGpb/HqsZO2dqlLJLL0Z1ZNxasV9qv2etnLN5dW93iSGklzRDPWw3TN4bfLFcYUzllVPEgV+9Twiit3aZKQ0p3dxq3p5R165OZMWvzKJ5mOJlGLENJFblaprJPYJbbymTCyiS58ru/5iZ/4FaAnEuSpI4tXkHrE7snaJVnnCdMRiIYJo+H/AHBJz2j0+T2tk2pBQvCU5FgxG2JJyHGJpPgWFgrZm7t5PH5MqJKEwFU4d7Mw+XGvC22It6M0HSrrrlEyImPAg+CjvA0H2yh5CgxFRsYYgjZNnmeMDVM8QyAG8LEczQaB44Jb1yesIRJCsuefvCUkluviBS1NR316eClQ6+fcQwGM/wBtYatRBDfiCrPXXpEeapxQwADnGGBUNUa1hgmQAFKno3W8NLgQwLhFb6wAGQuhHCAqMJSoQD5QDOE8Y7CJ6rChASbpEqWtK1jGCQCMiGqoP6Z8YnX7aETlLUhAQgAeHhlChRm1o/5bnq/hNRvSyxtj16mUsiQFngY0djnpBBUnEAzh2xDUYtMtoUKNGOx5iorSfmTLLgwKUuWFYSCfGoYgopSlIAoKuXLabQy8JyJkxSkpIBbzKxElgFEqYZkHqkKFDIyLZZXdEKSTiBxp1Yggg146QZRK1KmEAFRdkjCnTTRyK84UKAGTLtu8TJSnmBDLlhYKMRwrLJUktQu7gM/KkVSCJZUxTjDpqnEU5eIOG+8KFBzOku7fy+pXmyhmHMcsvxEYyIUKA5GGUAK5k/DfWCIkiFCgHckKsuHDl4khQ5H7x0ohQoUXdBLDOph2GhG4Y8tRyoIUKGIaiWBlHSYUKGAay5tV9IlzEmpL0zrtpChQhDRmR1zgSlEMOcKFDAZLNa6xMC/sG9THIUIBhXRn0/eI86ZUbR2FAABa6mGPChQDG4oRhQoYDcUSJE1gQOuHxChQgOmfChQoAP/Z',
  },
  {
    id: 5,
    title: 'Fried Rice',
    imageUrl: 'https://cicili.tv/wp-content/uploads/2025/08/Thai-Shrimp-Fried-Rice-Small-1.jpg',
  },
  {
    id: 6,
    title: 'Paratha',
    imageUrl: 'https://images.unsplash.com/photo-1683533743190-89c9b19f9ea6?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cGFyYXRoYXxlbnwwfHwwfHx8MA%3D%3D',
  },
];

const Restaurants = [
  {
    id: 1,
    title: 'Three Anandhaas',
    rating: 4.3,
    price: '₹250',
    time: '33 min',
    cuisines: 'South Indian, North Indian,...',
    offer: '₹100 OFF',
    imageUrl: 'https://via.placeholder.com/300x200?text=Three+Anandhaas',
    promoted: true,
  },
  {
    id: 2,
    title: 'SS Hyderabad Biryani-Coimba',
    rating: 4.4,
    price: '₹200',
    time: '35 min',
    cuisines: 'Biryani, Chinese, Mughlai,...',
    offer: '',
    imageUrl: 'https://via.placeholder.com/300x200?text=SS+Hyderabad+Biryani',
  },
  {
    id: 3,
    title: 'Woow Biryani',
    rating: 4.0,
    price: '₹100',
    time: '26 min',
    cuisines: 'South Indian, Biryani',
    offer: '₹100 OFF',
    imageUrl: 'https://via.placeholder.com/300x200?text=Woow+Biryani',
    promoted: true,
  },
  {
    id: 4,
    title: 'KFC',
    rating: 4.2,
    price: '₹300',
    time: '20 min',
    cuisines: 'Fast Food, American, Chicken',
    offer: '₹50 OFF',
    imageUrl: 'https://via.placeholder.com/300x200?text=KFC',
    promoted: false,
  },
  {
    id: 5,
    title: 'Dominos',
    rating: 4.1,
    price: '₹400',
    time: '25 min',
    cuisines: 'Pizza, Italian, Fast Food',
    offer: '',
    imageUrl: 'https://via.placeholder.com/300x200?text=Dominos',
    promoted: true,
  },
  {
    id: 6,
    title: 'Saravana Bhavan',
    rating: 4.5,
    price: '₹150',
    time: '30 min',
    cuisines: 'South Indian, Vegetarian',
    offer: '₹20 OFF',
    imageUrl: 'https://via.placeholder.com/300x200?text=Saravana+Bhavan',
    promoted: false,
  },
  {
    id: 7,
    title: 'Boomerang Ice Creams',
    rating: 4.3,
    price: '₹200',
    time: '15 min',
    cuisines: 'Desserts, Ice Cream',
    offer: '',
    imageUrl: 'https://via.placeholder.com/300x200?text=Boomerang+Ice+Creams',
    promoted: true,
  },
  {
    id: 8,
    title: 'SS Hyderabad Biryani',
    rating: 4.4,
    price: '₹180',
    time: '28 min',
    cuisines: 'Biryani, Mughlai',
    offer: '₹30 OFF',
    imageUrl: 'https://via.placeholder.com/300x200?text=SS+Hyderabad+Biryani+2',
    promoted: false,
  },
  {
    id: 9,
    title: 'Geetham Canteen',
    rating: 4.0,
    price: '₹100',
    time: '10 min',
    cuisines: 'South Indian, Snacks',
    offer: '',
    imageUrl: 'https://via.placeholder.com/300x200?text=Geetham+Canteen',
    promoted: false,
  },
];

export default function Order() {
  return (
    <div style={styles.container}>
      {/* Inspiration Section */}
      <section style={styles.inspirationSection}>
        <h2 style={styles.sectionTitle}>Inspiration for your first order</h2>
        <div style={styles.categoryGrid}>
          {InspirationCategories.map((category) => (
            <div key={category.id} style={styles.categoryCard}>
              <img
                src={category.imageUrl}
                alt={category.title}
                style={styles.categoryImage}
              />
              <p style={styles.categoryLabel}>{category.title}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Restaurants Section */}
      <section style={styles.restaurantsSection}>
        <h2 style={styles.sectionTitle}>Food Delivery Restaurants in Coimbatore</h2>
        <div style={styles.restaurantGrid}>
          {Restaurants.map((restaurant) => (
            <div key={restaurant.id} style={styles.restaurantCard}>
              {restaurant.promoted && <div style={styles.promotedBadge}>Promoted</div>}
              <img
                src={restaurant.imageUrl}
                alt={restaurant.title}
                style={styles.restaurantImage}
              />
              {restaurant.offer && (
                <div style={styles.offerBadge}>{restaurant.offer}</div>
              )}
              <div style={styles.restaurantInfo}>
                <h3 style={styles.restaurantTitle}>{restaurant.title}</h3>
                <div style={styles.rating}>{restaurant.rating}★</div>
                <p style={styles.cuisines}>{restaurant.cuisines}</p>
                <div style={styles.details}>
                  <span style={styles.price}>{restaurant.price} for one</span>
                  <span style={styles.time}>{restaurant.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

// Inline Styles
const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    maxWidth: '1200px',
    margin: '0 auto',
    backgroundColor: '#fff',
    padding: '20px',
  },
  inspirationSection: {
    padding: '20px 0',
  },
  restaurantsSection: {
    padding: '20px 0',
  },
  sectionTitle: {
    marginBottom: '20px',
    fontSize: '24px',
    color: '#333',
  },
  categoryGrid: {
    display: 'flex',
    gap: '15px',
    overflowX: 'auto',
    paddingBottom: '10px',
  },
  categoryCard: {
    minWidth: '140px',
    textAlign: 'center',
    cursor: 'pointer',
  },
  categoryImage: {
    width: '100%',
    height: '140px',
    objectFit: 'cover',
    borderRadius: '8px',
    marginBottom: '5px',
  },
  categoryLabel: {
    margin: '0',
    fontSize: '14px',
    color: '#333',
    fontWeight: '500',
  },
  restaurantGrid: {
    display: 'flex',
    gap: '20px',
    overflowX: 'auto',
    paddingBottom: '10px',
  },
  restaurantCard: {
    position: 'relative',
    minWidth: '300px',
    backgroundColor: '#fff',
    borderRadius: '12px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    overflow: 'hidden',
    cursor: 'pointer',
  },
  promotedBadge: {
    position: 'absolute',
    top: '10px',
    left: '10px',
    backgroundColor: '#ff6b35',
    color: '#fff',
    padding: '4px 8px',
    fontSize: '12px',
    borderRadius: '4px',
    zIndex: 1,
  },
  restaurantImage: {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
  },
  offerBadge: {
    position: 'absolute',
    top: '10px',
    right: '10px',
    backgroundColor: '#00c851',
    color: '#fff',
    padding: '4px 8px',
    fontSize: '12px',
    borderRadius: '4px',
    zIndex: 1,
  },
  restaurantInfo: {
    padding: '15px',
  },
  restaurantTitle: {
    margin: '0 0 5px 0',
    fontSize: '16px',
    fontWeight: '600',
    color: '#333',
  },
  rating: {
    color: '#ffa500',
    fontWeight: 'bold',
    marginBottom: '5px',
  },
  cuisines: {
    margin: '0 0 10px 0',
    fontSize: '14px',
    color: '#666',
  },
  details: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '14px',
    color: '#333',
  },
  price: {
    fontWeight: '500',
  },
  time: {
    color: '#666',
  },
};